package com.example.taller1_fibonacci;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class vistaResultadoFactorial extends AppCompatActivity {
    private static TextView resultado;
    private static TextView numerosImplicados;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        int num;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_resultado_factorial);

        resultado = findViewById(R.id.txtVResulFactorial);
        numerosImplicados = findViewById(R.id.txtVNumFact);

        Intent intent = getIntent();
        num = intent.getIntExtra("numero", 0);
        factorial(num);
    }

    public static void factorial(int num)
    {
        String numeros = "", temp;
        int res = 1;
        ArrayList<Integer> multi = new ArrayList<>();

        for (int i = 1; i <= num; i++) {
            res = res * i;
            multi.add(i);
        }
        temp = resultado.getText().toString();
        resultado.setText(temp + Integer.toString(res));
        //System.out.println("El resultado es: " + res);
        for (int i = 0; i < num; i++)
        {
            numeros = numeros + multi.get(i);
            if (i < num - 1)
                numeros = numeros + "*";
        }
        temp = numerosImplicados.getText().toString();
        numerosImplicados.setText(temp + numeros);
        //System.out.println("multiplicandos: " + numeros);
    }


}
