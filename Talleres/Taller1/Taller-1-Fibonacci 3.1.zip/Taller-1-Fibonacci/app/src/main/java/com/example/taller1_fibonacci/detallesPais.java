package com.example.taller1_fibonacci;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class detallesPais extends AppCompatActivity {

    private TextView txtVPais;
    private TextView txtVCiudad;
    private TextView txtVIngles;
    private TextView txtVSigla;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        pais paisSeleccionado = new pais();
        ArrayList<pais> paises = new ArrayList<>();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_pais);

        /*Inflar*/
        txtVPais = findViewById(R.id.txtVPais);
        txtVCiudad = findViewById(R.id.txtVCiudad);
        txtVIngles = findViewById(R.id.txtVIngles);
        txtVSigla = findViewById(R.id.txtVSiglas);

        Intent intent = getIntent();
        paisSeleccionado = (pais)intent.getExtras().getSerializable("seleccionado");

        txtVPais.setText("Pais: " + paisSeleccionado.getNombre());
        txtVCiudad.setText("Ciudad: " + paisSeleccionado.getCapital());
        txtVSigla.setText("Siglas: " + paisSeleccionado.getSigla());
        txtVIngles.setText("Nombre en ingles: " + paisSeleccionado.getNombreIng());

    }
}
