package com.example.taller1_fibonacci;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class webActivity extends AppCompatActivity {

    private WebView myWeb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);

        myWeb = findViewById(R.id.webview);
        myWeb.loadUrl("https://es.wikipedia.org/wiki/Leonardo_de_Pisa");
    }
}
