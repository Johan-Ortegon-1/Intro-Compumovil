package com.example.taller1_fibonacci;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class vistaResultado extends AppCompatActivity {

    private LinearLayout paneScrollPrincipal;
    private ArrayList<TextView> resultados = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent = getIntent();
        int numCal = intent.getIntExtra("numero",0);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_resultado);
        /*Inflar elementos*/
        paneScrollPrincipal = findViewById(R.id.paneScrollPrincipal);
        /*Fibonacci:*/
        calcularFibonacci(numCal);


    }
    public void calcularFibonacci(int num)
    {
        ArrayList<Long> secuencia = new ArrayList<>();
        secuencia.add(new Long(0));
        secuencia.add(new Long(1));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        for(int i = 1; i < num; i++)
        {
            secuencia.add(i+1,secuencia.get(i) + secuencia.get(i-1));
        }
        for(int i = 0; i < num; i++)
        {
            TextView nuevoTV = new TextView(paneScrollPrincipal.getContext());
            nuevoTV.setText(Long.toString(secuencia.get(i)));
            nuevoTV.setLayoutParams(params);
            paneScrollPrincipal.addView(nuevoTV);
            resultados.add(nuevoTV);
        }
    }
}
