package com.example.taller1_fibonacci;

import java.io.Serializable;

public class pais implements Serializable
{
    private String capital;
    private String nombre;
    private String nombreIng;
    private String sigla;

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNombreIng(String nombreIng) {
        this.nombreIng = nombreIng;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getCapital() {
        return capital;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNombreIng() {
        return nombreIng;
    }

    public String getSigla() {
        return sigla;
    }

    @Override
    public String toString() {
        return  nombre;
    }
}
