package com.example.taller1_fibonacci;

import androidx.appcompat.app.AppCompatActivity;
import java.io.*;
import java.io.InputStream;
import java.util.ArrayList;
import android.content.Intent;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Spinner;
import java.util.Calendar;
import java.util.Date;

import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private Button btnCalcular;
    private TextView textoResultado;
    private TextView textoResultado2;
    private String resultado;
    private ArrayList<TextView> resultados = new ArrayList<>();
    private LinearLayout paneScrollPrincipal;
    private Spinner spnNumeros;
    private String numSpinner;

    /*Contadores*/
    private TextView txtVFechaFibo;
    private TextView txtVFechaFacto;
    private TextView txtVContFibo;
    private TextView txtVContFacto;

    private int contFibo = 0;
    private int contFact = 0;
    private Date fechaActual = new Date();
    private boolean fibo = false;
    private boolean fact = false;

    /*Paises*/
    private ListView LVPaises;
    private ArrayList<pais> paisesRegistrados = new ArrayList<>();
    private ArrayList<String> nombresP = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCalcular = findViewById(R.id.btnCalculate);
        paneScrollPrincipal = findViewById(R.id.paneScrollPrincipal);
        spnNumeros = findViewById(R.id.spnNumeros);

        /*Contador*/
        txtVFechaFibo = findViewById(R.id.txtVFechaFibo);
        txtVFechaFacto = findViewById(R.id.txtVFechaFact);
        txtVContFibo = findViewById(R.id.txtVCantFibo);
        txtVContFacto = findViewById(R.id.txtVCantFact);

        resultados.add(textoResultado);
        resultados.add(textoResultado2);
        spnNumeros.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                numSpinner = spnNumeros.getSelectedItem().toString();
                //Toast.makeText(getBaseContext(), "El item seleccionado es: "+" "+numSpinner, Toast.LENGTH_LONG).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    protected void onResume()
    {
        super.onResume();
        String temp = "";
        if (fact)
        {
            fechaActual = Calendar.getInstance().getTime();
            contFact = contFact + 1;
            temp = "Fecha último uso: ";
            temp = temp + fechaActual.toString();
            txtVFechaFacto.setText(temp);

            temp = "Cantidad: " + Integer.toString(contFact);
            txtVContFacto.setText(temp);
        }
        else if(fibo)
        {
            fechaActual = Calendar.getInstance().getTime();
            contFibo = contFibo + 1;
            temp = "Fecha último uso: ";
            temp = temp + fechaActual.toString();
            txtVFechaFibo.setText(temp);
            temp = "Cantidad: " + Integer.toString(contFibo);
            txtVContFibo.setText(temp);
        }
    }
    public void mostrarPises(View v)
    {
        fibo = false;
        fact = false;
        Intent intent = new Intent(MainActivity.this, listaPaises.class);
        startActivity(intent);
    }
    public void calcularFibo(View v)
    {
        String estadoActual;
        int tam = 0;
        long res, num1, num2;
        fact = false;
        fibo = true;
        ArrayList<String> secuencia = new ArrayList<String>();
        TextInputEditText numeroCalcular = findViewById(R.id.TIETobtenerNumero);
        if(numeroCalcular.getText().toString().equals(""))
            Toast.makeText(v.getContext() , "Por favor ingrese un número", Toast.LENGTH_SHORT).show();
        else {
            int numero = Integer.parseInt(numeroCalcular.getText().toString());
            Intent intent = new Intent(MainActivity.this, vistaResultado.class);
            intent.putExtra("numero", numero);
            startActivity(intent);
        }
    }
    public void webBiografia(View v)
    {
        fibo = false;
        fact = false;
        Intent intent = new Intent(MainActivity.this, webActivity.class);
        startActivity(intent);
    }
    public void calcularFactorial(View v)
    {
        fact = true;
        fibo = false;
        Intent intent = new Intent(MainActivity.this, vistaResultadoFactorial.class);
        intent.putExtra("numero", Integer.parseInt(numSpinner));
        startActivity(intent);
    }
}
