package com.example.taller1_fibonacci;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class listaPaises extends AppCompatActivity {

    /*Paises*/
    private ListView LVPaises;
    private ArrayList<pais> paisesRegistrados = new ArrayList<>();
    private ArrayList<String> nombresP = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_paises);

        /*Paises*/
        LVPaises = findViewById(R.id.LVPaises);

        LVPaises.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                pais p;
                p = (pais)LVPaises.getItemAtPosition(position);
                Intent intent = new Intent(getBaseContext(), detallesPais.class);
                intent.putExtra("seleccionado", p);
                startActivity(intent);
            }
        });

        try
        {
            JSONObject objeto = new JSONObject(llenarList());
            JSONArray arregloPaises = objeto.getJSONArray("paises");
            for(int i = 0; i < arregloPaises.length();i++)
            {
                JSONObject temp = arregloPaises.getJSONObject(i);
                pais nuevoPais = new pais();
                nuevoPais.setCapital(temp.getString("capital"));
                nuevoPais.setNombre(temp.getString("nombre_pais"));
                nuevoPais.setNombreIng(temp.getString("nombre_pais_int"));
                nuevoPais.setSigla(temp.getString("sigla"));
                paisesRegistrados.add(nuevoPais);
                nombresP.add(temp.getString("nombre_pais"));
                //Toast.makeText(getBaseContext(), temp.getString("nombre_pais"), Toast.LENGTH_LONG).show();
                ArrayAdapter<pais> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, paisesRegistrados);
                LVPaises.setAdapter(adapter);
            }
        }
        catch(JSONException e)
        {

        }


    }

    public String llenarList()
    {
        String json = null;
        try
        {
            InputStream is = this.getAssets().open("paises.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
            //Toast.makeText(getBaseContext(), json, Toast.LENGTH_LONG).show();
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}
